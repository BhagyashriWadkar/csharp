﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Inheritance
    {
        static void Main()
        {
            SuperComputer sp = new SuperComputer();
            Console.WriteLine(sp.BootUp());
            Console.WriteLine(sp.ShutDown());
            MainFrame mp = new MainFrame();
            Console.WriteLine(mp.BootUp());
            Console.WriteLine(mp.ShutDown());
            MicroComputer micro = new MicroComputer();
            Console.WriteLine(micro.BootUp());
            Console.WriteLine(micro.ShutDown());
            Console.ReadLine();

        }
        
    }
}
