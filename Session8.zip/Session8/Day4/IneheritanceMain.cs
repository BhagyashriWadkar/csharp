﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class InheritanceMain
    {
       
        static void Main()
        {
            
            Console.WriteLine("Enter Account type:Current|Saving");
            string type = Console.ReadLine();
            if(type=="Current")
            {
                CurrentAccount acc = new CurrentAccount();
                Console.WriteLine("Enter amount");
                int amount = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter action Deposite|WithDraw");
                string action = Console.ReadLine();
                if (action == "Deposite")
                    acc.Deposite(amount);
                else
                    acc.WithDraw(amount);
                
            }
            if (type == "Saving")
            {
                SavingAccount acc = new SavingAccount();
                Console.WriteLine("Enter amount");
                int amount = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter action Deposite|WithDraw");
                string action = Console.ReadLine();
                if (action == "Deposite")
                    acc.Deposite(amount);
                else
                    acc.WithDraw(amount);

            }
            Console.ReadLine();
        }
       
    }
}
