﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    sealed class Pen
    {
       static void Main()
        {
            Console.WriteLine( StartWriting());
           Console.WriteLine( StopWriting());
            Console.ReadLine();
        }
        static public string StartWriting()
        {
            return "Starting writting ";
        }
        static public string StopWriting()
        {
            return "Stopping writting ";
        }
    }
}
