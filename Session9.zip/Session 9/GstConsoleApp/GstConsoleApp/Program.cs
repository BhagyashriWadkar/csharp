﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gst;

namespace GstConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Gst_amount gst = new Gst_amount(1200,5);
            Console.WriteLine($"Gst amount is {gst.Calculate_Gst()}");
            Console.ReadLine();
        }
    }
}
