﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gst;

namespace GstConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter amount");
            int amount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter percentage");
            double percentage = Convert.ToDouble(Console.ReadLine());
            Gst_amount gst = new Gst_amount(amount,percentage);
            Console.WriteLine($"Gst amount is {gst.Calculate_Gst()}");
            Console.ReadLine();
        }
    }
}
