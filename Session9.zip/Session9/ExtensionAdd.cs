﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GstConsoleApp
{
    public static class ExtensionAdd
    {
        public static void add(this int i,int value)
        {
            if (i > 0)
            {
                Console.WriteLine($"Addition is { i + value}");
            }

            else
            {
                Console.WriteLine("Enter positive number only");
            }
        }
        public static void Main()
        {
            Console.WriteLine("Enter number");
            int num = Convert.ToInt32(Console.ReadLine());
           num.add(5);

            Console.ReadLine();
        }
    }
}
