﻿using System;

namespace Gst
{
    public class Gst_amount
    {
        int amount;
        double percentage;
         public Gst_amount(int amount,double percentage)
        {
            this.amount = amount;
            this.percentage = percentage;
        }
        public double Calculate_Gst()
        {
            return (amount * percentage) / 100;
        }
    }
}
