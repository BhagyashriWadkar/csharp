﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5
{
    class Jagged
    {
        static void Main()
        {
            Console.WriteLine("Enter number of rows");
            int r = Convert.ToInt32(Console.ReadLine());
            int[][] array = new int[r][];

            for (int i = 0; i < array.Length; i++)
            {
                int c = 0;
                Console.WriteLine("Enter number of Columns for {0} row", i);
                array[i] = Convert.ToInt32(Console.ReadLine());
            }  
                for (int j=0;j<c;j++)
                {
                    Console.WriteLine("Enter elements of {0} {1}",i,j);
                    int num1 = Convert.ToInt32(Console.ReadLine());
                   array[i][j]= num1;
                }

            }
            
            
            Console.WriteLine("Enter elements to Search :");
            int num = Convert.ToInt32(Console.ReadLine());
            //bool found = false;
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in array[i])
                {
                    if (temp == num)
                    {
                        Console.WriteLine("element {0} found at {1} row", num, i);
                        break;
                    }


                }

            }

            Console.ReadLine();



        }
    }
}
