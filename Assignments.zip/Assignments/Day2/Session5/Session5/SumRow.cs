﻿using System;


namespace Session5
{
    class SumRow
    {
        static void Main()
        {
            Console.WriteLine("Enter number of rows");
            int r = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter number of Colums");
            int c = Convert.ToInt32(Console.ReadLine());
            int[,] array = new int[r, c];
            Console.WriteLine("Enter elements");
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < c; j++)
                {
                    array[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            
            int sum = 0;
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < c; j++)
                {
                    sum = sum + array[i, j];
                }
                Console.WriteLine("Sum of {0} row is {1}",i,sum);
                sum = 0;
            }
            Console.ReadLine();
        }
    }
}
