﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;
            Console.WriteLine("Enter age");
            age = Convert.ToInt32(Console.ReadLine());
            if(age>18)
            {
                Console.WriteLine("Major");
            }
            else
            {
                Console.WriteLine("Minor");
            }
            Console.ReadLine();

        }
    }
}
