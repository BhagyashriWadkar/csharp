﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class MajorUsdingTernery
    {
        static void Main()
        {
            int age;
            Console.WriteLine("Enter age");
            age = Convert.ToInt32(Console.ReadLine());
            string result= age > 18 ? "Major" : "Minor";
            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}
