﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class DollerUser
    {
        static void Main()
        {
            Console.WriteLine("Enter Doller value");
            double doller =Convert.ToDouble(Console.ReadLine());
            double d = doller * 70.1;
            int rupees = (int)d;
            int ruppes1 = Convert.ToInt32(d);
            Console.WriteLine("{0} doller is {1} or {2}", doller, rupees, ruppes1);
            Console.WriteLine("Enter Rupees value");
            int input =Convert.ToInt32(Console.ReadLine());
            double output = input / 70.1;
            Console.WriteLine("{0} rupees is {1} doller", input, output);
            Console.ReadLine();
        }
    }
}
