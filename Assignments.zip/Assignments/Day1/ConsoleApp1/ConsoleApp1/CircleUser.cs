﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class CircleUser
    {
        static void Main(string[] args)
        {
            const double PI = 3.14;
            Console.WriteLine("Enter radius");
            int r = Convert.ToInt32( Console.ReadLine());
            double area = r * r * PI;
            Console.WriteLine("Area is {0}",area);
            Console.ReadLine();

        }
    }
}
