﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class Total_payable
    {
        static void Main()
        {
            Console.WriteLine("Enter Principle amount, Rate of interest,time");
            int p = Convert.ToInt32(Console.ReadLine());
            int r = Convert.ToInt32(Console.ReadLine());
            int t = Convert.ToInt32(Console.ReadLine());
            double interest_amt = 0;
            double  payable =0;
            interest_amt = interest(out payable,p, r, t);
            Console.WriteLine("Interest amount is {0} and payable amount is {1}", interest_amt,payable);
            Console.ReadLine();
        }
        static double interest(out double payable,int p, int r, int t)
        {
            int interest_amt = (p * r * t) / 100;
            payable = p + interest_amt;
            return interest_amt ;
        }
    }
}
