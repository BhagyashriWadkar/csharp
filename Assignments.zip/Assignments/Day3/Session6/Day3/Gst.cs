﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class Gst
    {
        static void Main()
        {
            Console.WriteLine("Enter Item: (Food | Service | Ornaments )");
           string Item = Console.ReadLine();
            Console.WriteLine("Enter Amount");
            int amount = Convert.ToInt32(Console.ReadLine());
            double GstAmount;
            double percentage=0.0;
            if (Item == "Food")
            {
                 calculate_gst(amount, 5);
            }
            else if (Item == "Service")
            {
               calculate_gst(amount, 4); 
            }
            else if(Item == "Ornaments")
            {
                calculate_gst(amount, 12);
            }
            else
            {
                calculate_gst(amount);
            }
            
            
            Console.ReadLine();
        }
        public static void calculate_gst(int amount,double percentage=0.01)
        {
             Console.WriteLine("Gst amount for {0} percentage is {1}", percentage, ((amount * percentage) / 100)) ;
        }

    }
}

