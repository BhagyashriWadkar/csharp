﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7
{
    class StudentStructure
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter roll number ,name, gender,number");
            int rollNo = Convert.ToInt32(Console.ReadLine());
            string name = Console.ReadLine();
            string gender = Console.ReadLine();
            int number = Convert.ToInt32(Console.ReadLine());
            Student std = new Student(rollNo, name, gender, number);
            Console.WriteLine(std.display());
            Console.ReadLine();
        }
        
    }
    struct Student
    {
        int rollNo;
        string name;
        string gender;
        int number;
        public Student(int rollNo, string name,string gender,int number)
        {
            this.rollNo = rollNo;
            this.name = name;
            this.gender = gender;
            this.number = number;
        }
        public string display()
        {
            return string.Format("roll number= {0} ,name= {1}, gender= {2},number= {3}",rollNo,name,gender,number);
        }
    }
    

}
