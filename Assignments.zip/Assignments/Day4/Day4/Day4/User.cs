﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class User
    {
        private long Id;
        private string emailId;
        private string name;
        private string Date_of_birth;
        public long UserId
        {
            
            get
            {
                return Id;
            }
            set
            {
                if (value <= 0)
                {
                    Console.WriteLine("User ID should be greater than 0");
                }
                else
                {
                    Id = value;
                }

            }
        }
    
        public string Email { get; set; }
        public string Username { get; set; }
        public string DOB { get; set; }

        public User()
        {
            Console.WriteLine("Default constructor of user");
        }
        public User(long Id, string name, string emailId,string DOB)
        {
            this.UserId = Id;
            this.name = name;
            this.emailId = emailId;
            this.DOB = DOB;
        }
        public override string ToString()
        {
            return string.Format("User Id is {0} name is {1} email id  is {2} Date of birth  is {3} ",Id,name,emailId,DOB);
        }
    }
}
