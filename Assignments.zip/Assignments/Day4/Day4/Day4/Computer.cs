﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    abstract class Computer
    {
       public string BootUp()
        {
            return "Booting up computer";
        }
        public string ShutDown()
        {
            return "shutting down computer";
        }

    }
}
