﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Hotel
    {
        static void Main()
        {
            Console.WriteLine("Enter room Number");
            int no = Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("Enter floor Number");
            int floor = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter room type");
            string type = Console.ReadLine();
            Console.WriteLine("Enter capacity");
            int capacity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Date of booking");
            DateTime date = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter room price");
            double price = Convert.ToDouble(Console.ReadLine());
            Room room = new Room();
            Room rm = new Room(no, floor, type,capacity, date, price);
            Console.WriteLine( rm.ToString());
            Console.ReadLine();
        }
       
    }
}
