﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Login
    {
        static void Main()
        {
            Console.WriteLine("Enter User Id");
            long Id = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter name of user");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Email address");
            string Email = Console.ReadLine();
            Console.WriteLine("Enter Date of birth");
            string DOB = Console.ReadLine();
            User us = new User();
            User user = new User(Id, name, Email, DOB);
            Console.WriteLine(user.ToString());
            Console.ReadLine();
        }
    }
}
