﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Room
    {
        private int roomNo;
        private int floorNo;
        private string roomType;
        private int roomcapacity;
        private DateTime roomDate;
        private double roomprice;
        public int No
        {
            get
            {
                return roomNo;
            }
            set
            {
                if (value <= 0)
                {
                    Console.WriteLine("Room Number should be greater than 0");
                }
                else
                {
                    roomNo = value;
                }

            }
        }

        public int floor
        {
            get
            {
                return floorNo;
            }
            set
            {
                if (value <= 0)
                {
                    Console.WriteLine("Floor Number should be greater than 0");
                }
                else
                {
                    floorNo = value;
                }
                
            }
        }
       

        public string Type
        {
            get
            {
                return roomType;
            }
            set
            {
                roomType = value;
               
            }
        }
        public int Capacity { get; set; }
        public DateTime Date { get; set; }
        public double Price { get; set; }
        public Room()
        {
            Console.WriteLine("Default constructor of Room");
        }
        public Room(int roomNo, int floorNo, string roomType, int roomcapacity, DateTime roomDate, double roomprice)
        {
            this.No = roomNo;
            this.floor = floorNo;
            this.roomType = roomType;
            this.Capacity = roomcapacity;
            this.Date = roomDate;
            this.Price = roomprice;
        }
        public override string ToString()
        {
            return string.Format("Room number is {0} Floor is {1} Type is {2} capacity is {3} Date is {4} price is {5}", No,floor, Type,Capacity,Date,Price);
        }
    }
   
}
