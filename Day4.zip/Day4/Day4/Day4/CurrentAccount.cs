﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class CurrentAccount
    {
        double balance = 1000;

        public void Deposite(double amount)
        {
            Console.WriteLine($"your balance is {balance}");
            balance =  balance + amount;
            Console.WriteLine($"Now your balance after depositting {amount} rs is {balance}");
        }
        public void WithDraw(double amount)
        {
            Console.WriteLine($"Now your balance after depositting {amount}rs is {balance}");
            if(amount<balance)
            {
                balance = balance - amount;
                Console.WriteLine($"Now your balance after withdrawing {amount} rs is {balance}");
            }
            else
            {
                Console.WriteLine($"Amount is greater than Balance");
            }
           
        }
    }
}
