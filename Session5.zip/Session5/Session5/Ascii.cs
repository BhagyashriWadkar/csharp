﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5
{
    class Ascii
    {
        static void Main()
        {
            int[] ascii = new int[10];int j = 0;
            for(char i='a';i<='i'; i++)
            {
                ascii[j] = (int)i;
                j++;
                Console.WriteLine("ascii for {0} is {1}", i, (int)i);
            }
            int[,] array = new int[3, 3];
            int k = 0;
            for(int r=0;r<3;r++)
            {
                for(int c=0;c<3;c++)
                {
                    array[r, c] = ascii[k];
                    k++;
                }
            }
            Console.WriteLine("\n Array is\n");
            for (int r = 0; r < 3; r++)
            {
                for (int c = 0; c < 3; c++)
                {
                    Console.Write("{0}\t", array[r, c]);
                }
                Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}
