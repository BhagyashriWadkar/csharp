﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Ascii
    {
        static void Main()
        {
            char convert1 = 'a';
            int ascii = convert1;
            int ascii1 = 98;
            char output = (char)ascii1;
            Console.WriteLine("input is {0} output is {1} \ninput is {2} output is {3}",convert1, ascii,ascii1,output);
            Console.ReadLine();
        }
        

    }
}
