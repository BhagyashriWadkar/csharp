﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class AsciiUser
    {
        static void Main()
        {
            Console.WriteLine("Enter character");
            char convert1 = Convert.ToChar(Console.ReadLine());
            int ascii = convert1;
            Console.WriteLine("Enter ascii");
            int ascii1 =Convert.ToInt32( Console.ReadLine());
            char output = (char)ascii1;
            Console.WriteLine("input is {0} output is {1} \ninput is {2} output is {3}", convert1, ascii, ascii1, output);
            Console.ReadLine();
        }
    }
}
