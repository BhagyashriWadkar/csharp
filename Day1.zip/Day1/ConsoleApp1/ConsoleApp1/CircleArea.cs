﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class CircleArea
    {
        static void Main(string[] args)
        {
            const double PI = 3.14;
            int r = 5;
            double area = r * r * PI;
            Console.WriteLine(area);
            Console.ReadLine();

        }
    }
}
