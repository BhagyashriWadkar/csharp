﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7
{
    class enumMain
    {
        static void Main()
        {
            Console.WriteLine("cities are");
            foreach (String city in Enum.GetNames(typeof(CityEnum)))
            {
                Console.WriteLine(city);
            }
            Console.WriteLine("\nvalues are");
            foreach (int code in Enum.GetValues(typeof(CityEnum)))
            {
                Console.WriteLine(code);
            }
            Console.ReadLine();
        }

    }
}
