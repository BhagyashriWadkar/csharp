﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7
{
    enum CityEnum
    {
        pune=202,Mumbai=201,Satara=204
    }
}
