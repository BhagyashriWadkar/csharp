﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class Search
    {
        static void Main()
        {
            
            int[][] array = new int[2][];
            array[0] = new int[3] { 10, 20, 30 };
            array[1] = new int[2] { 1, 2 };
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in array[i])
                {
                    Console.Write("{0}\t", temp);
                }
                Console.WriteLine();
            }


            Console.WriteLine("Enter number to search");
            int num = Convert.ToInt32(Console.ReadLine());
            bool flag = SearchEle(array,num);
            if(flag)
            {
                Console.WriteLine("{0} found",num);
            }
            else
            {
                Console.WriteLine(" {0} not found", num);
            }
            Console.ReadLine();

        }
        public static bool SearchEle(int[][] array,int num)
        {
            bool flag = false;
            for(int i=0;i<2;i++)
            {
                foreach(int temp in array[i])
                {
                    if(temp== num)
                    {
                        flag = true;
                    }
                }
            }


            return flag;
        }
    }
}
