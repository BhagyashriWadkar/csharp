﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class SimpleInterest
    {
        static void Main()
        {
            Console.WriteLine("Enter Principle amount, Rate of interest,time");
            int p = Convert.ToInt32(Console.ReadLine());
            int r = Convert.ToInt32(Console.ReadLine());
            int t = Convert.ToInt32(Console.ReadLine());
            double interest_amt = 0;
            interest_amt= interest(p, r, t);
            Console.WriteLine("Inetrest amount is {0}", interest_amt);
            Console.ReadLine();
        }
        static double interest(int p,int r,int t)
        {
            return (p * r * t) / 100;
        }
    }
}
