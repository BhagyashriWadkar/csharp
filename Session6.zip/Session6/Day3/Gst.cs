﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class Gst
    {
        static void Main()
        {
            Console.WriteLine("Enter Item: (Food | Service | Ornaments | Other)");
           string Item = Console.ReadLine();
            Console.WriteLine("Enter Amount");
            int amount = Convert.ToInt32(Console.ReadLine());
            if (Item == "Food")
            {
                Console.WriteLine("Final amount is {0} ", calculate_gst(amount, 5));
            }
            else if (Item == "Service")
            {
                Console.WriteLine("Final amount is {0} ", calculate_gst(amount, 4));
            }
            else if(Item == "Ornaments")
            {
                Console.WriteLine("Final amount is {0} ", calculate_gst(amount, 12));
            }
            else
            {
                Console.WriteLine("Final amount is {0} ", calculate_gst(amount));

            }
            
            
            Console.ReadLine();
        }
        public static double calculate_gst(int amount,double percentage=1)
        {
            double gst_amt= (amount * percentage) / 100;
            double final_amt = amount + gst_amt;
             Console.WriteLine("Gst amount for {0} percentage is {1}", percentage,gst_amt ) ;
            return final_amt;
        }

    }
}

