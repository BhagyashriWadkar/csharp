﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class Fcatorial

    {
        static void Main(string[] args)
        {
            int num = 0;
            Console.WriteLine("Enter number");
            num= Convert.ToInt32( Console.ReadLine());
            int output = fact(num);
            Console.WriteLine("Factorial is {0}",output);
            Console.ReadLine();
        }
        public static int fact(int num)
        {
            int output  = 1;
            while (num > 0)
            {
                output = output * num;
                num--;
            }
            return output;
                
        }
       
    }
}
