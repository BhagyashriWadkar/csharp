﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5
{
    class Diagonal
    {
        static void Main()
        {
            Console.WriteLine("Enter number of rows");
            int r= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter number of Columns");
            int c = Convert.ToInt32(Console.ReadLine());
            int[,] array = new int[r, c];
            Console.WriteLine("Enter elements");
            for(int i=0;i<r;i++)
            {
                for(int j=0;j<c;j++)
                {
                    array[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("Diagonal elements are :");
            int sum = 0;
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < c; j++)
                {
                    if(i==j)
                    {
                        
                        sum=sum + array[i, j];
                        Console.WriteLine(array[i,j]);
                    }
                }

            }
            Console.WriteLine("Sum is :{0}",sum);
            Console.ReadLine();
        }
    }
}
