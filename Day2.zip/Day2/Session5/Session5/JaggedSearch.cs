﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5
{
    class JaggedSearch
    {
        static void Main()
        {
            //Console.WriteLine("Enter number of rows");
            //int r = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Enter number of Columns");
            //int c = Convert.ToInt32(Console.ReadLine());
            //int[][] array = new int[r][];
            int[][] array = new int[2][];
            array[0] = new int[3] { 10, 20, 30 };
            array[1] = new int[2] { 1, 2 };

            

            Console.WriteLine("Enter elements to Search :");
            int num = Convert.ToInt32(Console.ReadLine());
            //bool found = false;
            for (int i = 0; i < 2; i++)
            {
                foreach(int temp in array[i])
                {
                    if (temp == num)
                    {
                        Console.WriteLine("element {0} found at {1} row",num,i);
                        break;
                    }
                    
                        
                }

            }
             
            Console.ReadLine();



        }
    }
}
