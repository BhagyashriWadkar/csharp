﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Grade
    {
        static void Main()
        {
            int percentage;
            Console.WriteLine("Enter percentage");
            percentage = Convert.ToInt32(Console.ReadLine());
            if(percentage>75)
            {
                Console.WriteLine("Distinction");
            }
            else if (percentage <75&& percentage>60)
            {
                Console.WriteLine("first class");

            }
            else if (percentage < 75 && percentage >60 )
            {
                Console.WriteLine("first class");

            }
            else if (percentage < 60 && percentage > 50)
            {
                Console.WriteLine("Second class");

            }
            else if (percentage < 50 && percentage > 35)
            {
                Console.WriteLine("Pass");

            }
            else
            {
                Console.WriteLine("Fail");
            }
            Console.ReadLine();

        }
    }
}
