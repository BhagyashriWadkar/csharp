﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4
{
    class TableFor
    {
        static void Main()
        {
            Console.WriteLine("Enter number ");
            int number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Table of {0} is ",number);
            for (int i=1;i<=10;i++)
            {
                Console.WriteLine(number*i);
            }
            Console.ReadLine();
        }
    }
}
